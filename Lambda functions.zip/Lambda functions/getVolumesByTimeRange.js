'use strict';

var AWS = require("aws-sdk");

AWS.config.update({
  region: "us-east-1"
});

var docClient = new AWS.DynamoDB.DocumentClient();
console.log('Lambda getVolumesByTimeRange function');

exports.handler = (event, context, callback) => {

    var table = "volumes";
    var defaultTime = Date.now();
    var userName = event.userName ? event.userName : null;
    var start = event.startTime ? event.startTime : defaultTime;
    var end = event.endTime ? event.endTime : defaultTime;

    var params = {
        TableName: table,
        KeyConditionExpression: "#userName = :userName and startTime between :startTime and :endTime",
        ExpressionAttributeNames:{
            "#userName": "userName"
        },
        ExpressionAttributeValues: {
            ":userName": userName,
            ":startTime": start,
            ":endTime": end
        }
    };
    docClient.query(params, callback);
    //dynamo.updateItem(payload, callback);
  //callback(null, {userName: userName, startTime: startTime, endTime: endTime}); // SUCCESS with message
};
