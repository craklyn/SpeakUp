'use strict';

var AWS = require("aws-sdk");

AWS.config.update({
  region: "us-east-1"
});

var docClient = new AWS.DynamoDB.DocumentClient();
console.log('Loading function');
//const doc = require('dynamodb-doc');
//const dynamo = new doc.DynamoDB();

exports.handler = (event, context, callback) => {
    var jobID = (event.jobID === undefined ? 'No-jobID' : event.jobID);
    var userName = (event.userName === undefined ? 'No-userName' : event.userName);
    var startTime = (event.startTime === undefined ? 'No-startTime' : (new Date(event.startTime)).getTime());
    var endTime = (event.endTime === undefined ? 'No-endTime' : (new Date(event.endTime)).getTime());
    var textToken = (event.textToken === undefined ? 'No-textToken' : event.textToken);
    var sentiment = (event.sentiment === undefined ? 'No-sentiment' : event.sentiment);
    var speechVolume = (event.speechVolume === undefined? [] : event.speechVolume);
    
    const payloadR = {
        TableName: "records",
        Item: {
            jobID: jobID, 
            userName: userName, 
            startTime: startTime, 
            endTime: endTime, 
            textToken: textToken, 
            sentiment: sentiment,
            speechVolume: speechVolume
        }
    };
    
    docClient.put(payloadR, callback);
    
    var gap = 250;
    speechVolume.forEach(function(volume) {
        
        const payloadV = {
            TableName: "volumes",
            Item: {
                userName: userName,
                startTime: startTime,
                volume: volume
            }
        };
        
        docClient.put(payloadV, callback);
        startTime += gap;
    });
    //dynamo.updateItem(payload, callback);
  //callback(null, {userName: userName, startTime: startTime, endTime: endTime}); // SUCCESS with message
};
