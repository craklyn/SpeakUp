'use strict';

var AWS = require("aws-sdk");

AWS.config.update({
  region: "us-east-1"
});

var docClient = new AWS.DynamoDB.DocumentClient();
console.log('Lambda getRecord function');

exports.handler = (event, context, callback) => {

    var table = "records";
    var userName = event.userName ? event.userName : null;

    var params = {
        TableName: table
    };
    docClient.scan(params, callback);
    //dynamo.updateItem(payload, callback);
  //callback(null, {userName: userName, startTime: startTime, endTime: endTime}); // SUCCESS with message
};
