# SpeakUp Group UI

This project is an single page web application written in AngularJS and D3JS for the SpeakUp artificial intelligence system, which is aim to collect and analysis meeting data of participants, such as individual speak time and percentage during a meeting.

