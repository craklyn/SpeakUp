(function() {
	'use strict';

	// Declare app level module which depends on views, and components
	angular.module('myApp', []).
	controller('GreetingController', ['$scope', function($scope) {
		var docClient;
	  $scope.greeting = 'Hola!';
	  $scope.members = [
	  	{
	  		"name": "Sarah",
	  		"participation": 30,
	  		"interruption": 2
	  	},
	  	{
	  		"name": "John",
	  		"participation": 20,
	  		"interruption": 15
	  	},
	  	{
	  		"name": "Bob",
	  		"participation": 50,
	  		"interruption": 12
	  	}
	  ];

	  function getData() {
	  	if (docClient) {
	  		var table = "records";
	  		var params = {
	  			TableName: table
	  		};
	  		docClient.scan(params, function(err, data) {
	  			console.log(data);
	  		})
	  	}
	  }

	  function setUpSDK() {
		AWS.config.update({accessKeyId: 'xx', secretAccessKey: 'xxx'});
	  	AWS.config.region = "us-east-1";
	  	docClient = new AWS.DynamoDB.DocumentClient();
	  }

	  setUpSDK();
	  getData();

	}]);;
}());
